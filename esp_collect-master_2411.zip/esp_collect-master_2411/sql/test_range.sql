def env_diagnostics_pack = 'Y'
def env_conf_dbid=''
def env_conf_date_from = 'YYYY-MM-DD'; 
def env_conf_date_to ='YYYY-MM-DD';
def env_conf_days = '365';
def env_conf_dd_mode = 'AUTO'
def env_conf_con_option ='A'
def env_conf_is_cdb ='A'

@sql/detect_environment.sql

def
